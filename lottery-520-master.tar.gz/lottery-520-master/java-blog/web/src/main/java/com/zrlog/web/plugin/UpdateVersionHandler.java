package com.zrlog.web.plugin;

public interface UpdateVersionHandler {

    String getMessage();

    boolean isFinish();

    void start();
}
