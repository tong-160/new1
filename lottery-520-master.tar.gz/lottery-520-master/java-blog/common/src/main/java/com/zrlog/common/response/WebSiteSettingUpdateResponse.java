package com.zrlog.common.response;

public class WebSiteSettingUpdateResponse extends StandardResponse {

}
