package com.zrlog.common.vo;

import java.util.ArrayList;

public class OutlineVO extends ArrayList<Outline> {


}
